package com.emergentes.modelo;

public class Persona {
    private int id;
    private String nombre;
    private int nota1;
    private int nota2;
    private int exfi;
    private int nota;

    public Persona() {
        this.id = 0;
        this.nombre = "";
        this.nota1 = 0;
        this.nota2 = 0;
        this.exfi = 0;
        this.nota = 0;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNota1() {
        return nota1;
    }

    public void setNota1(int nota1) {
        this.nota1 = nota1;
    }

    public int getNota2() {
        return nota2;
    }

    public void setNota2(int nota2) {
        this.nota2 = nota2;
    }

    public int getExfi() {
        return exfi;
    }

    public void setExfi(int exfi) {
        this.exfi = exfi;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
