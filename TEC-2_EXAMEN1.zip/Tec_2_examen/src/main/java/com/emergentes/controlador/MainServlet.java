package com.emergentes.controlador;

import com.emergentes.modelo.Persona;
import java.io.IOException;
import java.util.ArrayList;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "MainServlet", urlPatterns = {"/MainServlet"})
public class MainServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession ses = request.getSession();
        
        if(ses.getAttribute("listapersonas") == null)
        {
           ArrayList<Persona> listaux = new ArrayList<Persona>();
           ses.setAttribute("listapersonas", listaux);
        }
       
        ArrayList<Persona> lista = (ArrayList<Persona>) ses.getAttribute("listapersonas");
        
        String op = request.getParameter("op");
        String opcion = (op != null) ? request.getParameter("op") : "view";
        
        Persona obj1 = new Persona();
        int id, pos;
        switch(opcion)
        {   
            case "nuevo": 
                request.setAttribute("miPersona", obj1);
                request.getRequestDispatcher("editar.jsp").forward(request, response);
                break;
            case "editar":
                id = Integer.parseInt(request.getParameter("id"));
                pos = buscarIndice(request, id);
                obj1 = lista.get(pos);
                request.setAttribute("miPersona", obj1);
                request.getRequestDispatcher("editar.jsp").forward(request, response);
                break;
            case "eliminar":
                id = Integer.parseInt(request.getParameter("id"));
                pos = buscarIndice(request, id);
                lista.remove(pos);
                ses.setAttribute("listapersonas", lista);
                response.sendRedirect("index.jsp");
                break;
            case "view": 
                response.sendRedirect("index.jsp");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession ses = request.getSession();
        ArrayList<Persona> lista = (ArrayList<Persona>) ses.getAttribute("listapersonas");
        
        Persona obj1 = new Persona();
        
        obj1.setId(Integer.parseInt(request.getParameter("id")));
        obj1.setNombre(request.getParameter("nombre"));
        obj1.setNota1(Integer.parseInt(request.getParameter("nota1")));
        obj1.setNota2(Integer.parseInt(request.getParameter("nota2")));
        obj1.setExfi(Integer.parseInt(request.getParameter("exfi")));
        
         // Calcular el promedio 
    int promedio = (obj1.getNota1() + obj1.getNota2() + obj1.getExfi()) / 3;
    obj1.setNota(promedio);
        
        int idt = obj1.getId();
        
        if(idt == 0)
        {
            int ultID;
            ultID = ultimoId(request);
            obj1.setId(ultID);
            lista.add(obj1);
        }
        else 
        {
            lista.set(buscarIndice(request,idt), obj1);
        }
        ses.setAttribute("listapersonas", lista);
        response.sendRedirect("index.jsp");
    }
    
    private int buscarIndice(HttpServletRequest request, int id)
    {
        HttpSession ses = request.getSession();
        ArrayList<Persona> lista = (ArrayList<Persona>) ses.getAttribute("listapersonas");
        
        int i = 0;
        if(lista.size() > 0)
        {
            while(i < lista.size())
            {
                if(lista.get(i).getId() == id)
                {
                    break;
                }
                else 
                {
                    i++;
                }
            }
        }
        return i;
    }
    
    private int ultimoId(HttpServletRequest request)
    {
        HttpSession ses = request.getSession();
        ArrayList<Persona> lista = (ArrayList<Persona>) ses.getAttribute("listapersonas");
        
        int idaux = 0;
        
        for(Persona item : lista)
        {
            idaux = item.getId();
        }
        return idaux + 1;
    }
}
